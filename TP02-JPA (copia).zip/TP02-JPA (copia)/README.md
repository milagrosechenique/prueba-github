# Desarrollo-De-Software
# TP grupal: Consultas avanzadas con JPQL

Proyecto de facturación con 20 consultas JPQL. Las consultas se encuentran en `ConsultasJPQL.java`; `Main.java` las ejecuta en orden y muestra sus resultados por consola.

## Requisitos

- JDK 21, según `maven.compiler.release` del `pom.xml`.
- Maven.
- MySQL activo. El entorno utilizado para la práctica tiene MySQL 8.0.42.

## Preparar la base

Desde una sesión de MySQL con permisos de administración, ejecutar:

```sql
CREATE DATABASE IF NOT EXISTS tp_jpql;
CREATE USER 'usuario_jpql'@'localhost' IDENTIFIED BY 'REEMPLAZAR_CON_CLAVE_LOCAL';
GRANT ALL PRIVILEGES ON tp_jpql.* TO 'usuario_jpql'@'localhost';
```

Elegir una contraseña local en lugar del texto de ejemplo. Si el usuario ya existe, omitir `CREATE USER` y utilizar sus credenciales. No es necesario cambiar la contraseña de Ubuntu ni la de root de MySQL.

## Configurar JPA

En `src/main/resources/META-INF/persistence.xml`, ajustar las propiedades de conexión al entorno local:

```xml
<property name="jakarta.persistence.jdbc.driver" value="com.mysql.cj.jdbc.Driver"/>
<property name="jakarta.persistence.jdbc.url" value="jdbc:mysql://localhost:3306/tp_jpql"/>
<property name="jakarta.persistence.jdbc.user" value="usuario_jpql"/>
<property name="jakarta.persistence.jdbc.password" value="REEMPLAZAR_CON_CLAVE_LOCAL"/>
<property name="hibernate.dialect" value="org.hibernate.dialect.MySQLDialect"/>
<property name="hibernate.hbm2ddl.auto" value="update"/>
```

La contraseña debe coincidir con la elegida en MySQL. Cada integrante o evaluador debe configurar sus propios datos de acceso. La unidad de persistencia conserva el nombre `FacturacionPU`.

Hibernate crea o actualiza las tablas dentro de la base existente mediante `update`; la base se crea previamente con el comando SQL.

## Ejecutar

Abrir una terminal en la carpeta `TP02-JPA`, donde se encuentra `pom.xml`:

```bash
java -version
mvn -version
mvn compile exec:java
```

Comprobar que Java y el Java utilizado por Maven sean de versión 21 o compatible con compilación para Java 21. El plugin de ejecución ya especifica `ar.edu.utn.tp2.Main` como clase principal.

También puede ejecutarse `Main.java` desde VS Code con las extensiones de Java y un JDK adecuado.

## Carga inicial y ejecuciones posteriores

La versión preparada de `Main.java` cuenta las facturas antes de cargar datos:

```java
Long cantidadFacturas = entityManager
    .createQuery("SELECT COUNT(f) FROM FacturaVenta f", Long.class)
    .getSingleResult();

if (cantidadFacturas == 0) {
    // Bloque existente de creación y persistencia de datos,
    // incluyendo begin(), GeneradorDatos.cargarDatos(...) y commit().
}
// Las 20 llamadas a ConsultasJPQL permanecen fuera del if.
```

En una base nueva se cargan los datos de prueba. Cuando ya hay facturas, se omite la carga y se ejecutan las 20 consultas. Este mecanismo está pensado para una práctica ejecutada por un proceso sobre una base dedicada; no reconstruye datos faltantes en bases parcialmente cargadas.

## Consultas incluidas

| Punto | Operación |
|---|---|
| 1 | Todas las facturas como entidades completas |
| 2 | Número, fecha de emisión e importe total |
| 3 | Artículos por denominación de rubro |
| 4 | Facturas por rango de fechas |
| 5 | Estado, importe mínimo y ausencia de anulación |
| 6 | Clientes por texto parcial o prefijo de CUIT/CUIL |
| 7 | Estados distintos ordenados |
| 8 | Cantidad, suma y promedio de facturas emitidas |
| 9 | Puntos de venta incluidos en una lista |
| 10 | Facturas por usuario de carga |
| 11 | Detalles por punto de venta con INNER JOIN |
| 12 | Artículos y marcas con LEFT JOIN |
| 13 | Facturas con artículos de una marca |
| 14 | Facturas con total mayor al promedio |
| 15 | Cantidad y total de facturas por punto de venta |
| 16 | Usuarios con más de cinco facturas |
| 17 | Unidades y subtotal por marca |
| 18 | Marcas con artículos facturados mediante EXISTS |
| 19 | Artículos nunca facturados mediante NOT EXISTS |
| 20 | Clasificación por importe mediante CASE y orden descendente |

Las consultas usan entidades y atributos Java, `createQuery(jpql, ClaseDestino.class)` y parámetros nombrados para los valores recibidos desde Java. Las proyecciones múltiples utilizan `Object[].class`.

## Interpretar los resultados

- Los mensajes `Hibernate:` muestran el SQL generado a partir de JPQL.
- Los títulos `Consulta 1` a `Consulta 20` identifican los resultados de cada punto.
- Un resultado vacío puede ser correcto: los datos iniciales contienen tres facturas, por lo que ningún usuario supera cinco facturas en el punto 16.
- El punto 4 utiliza un rango relativo a la fecha de ejecución; al pasar los días puede dejar de incluir facturas antiguas.
- Los importes de prueba incluyen valores altos y bajos; no incluyen un ejemplo de valor medio para el punto 20.

## Comprobaciones realizadas

Se observó la ejecución de las 20 llamadas hasta el punto 20 en el entorno de la práctica, después de corregir el tipo del número de factura a `Long`. Se verificó que el punto 18 devuelve marcas y que el punto 19 devuelve el artículo sin ventas. La carga con base inicialmente vacía debe comprobarse con la versión final del bloque condicional; las pruebas sobre una base ya cargada comprueban únicamente que no se repite la carga.

## Archivos para entregar

Incluir `src/`, `pom.xml` y este README dentro de la carpeta del proyecto. La carpeta `target/` contiene archivos generados y no es necesaria para recompilar. Si se comparte en GitHub, los cambios locales deben subirse para que la versión publicada coincida con la entrega.
Trabajos y prácticos de la materia
